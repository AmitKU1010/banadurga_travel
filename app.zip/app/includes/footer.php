<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © <?php echo date('Y')?> United Engineering
        </div>
      </div>
    </footer>