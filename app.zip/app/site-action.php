<?php
  include('includes/config.php');

  if($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    // insert to the database
    if(isset($_POST['submit']))
    {

    }
    // Update to the database
    if(isset($_POST['update']))
    {
      
    }
  }
  
  // delete to the database
  if(isset($_POST['delete']))
    {
      
    }

?>